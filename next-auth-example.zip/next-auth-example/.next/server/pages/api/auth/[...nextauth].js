"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/auth/[...nextauth]";
exports.ids = ["pages/api/auth/[...nextauth]"];
exports.modules = {

/***/ "next-auth":
/*!****************************!*\
  !*** external "next-auth" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ "next-auth/providers/azure-ad":
/*!***********************************************!*\
  !*** external "next-auth/providers/azure-ad" ***!
  \***********************************************/
/***/ ((module) => {

module.exports = require("next-auth/providers/azure-ad");

/***/ }),

/***/ "(api)/./pages/api/auth/[...nextauth].ts":
/*!*****************************************!*\
  !*** ./pages/api/auth/[...nextauth].ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"authOptions\": () => (/* binding */ authOptions),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-auth */ \"next-auth\");\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth_providers_azure_ad__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/providers/azure-ad */ \"next-auth/providers/azure-ad\");\n/* harmony import */ var next_auth_providers_azure_ad__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_azure_ad__WEBPACK_IMPORTED_MODULE_1__);\n\n\n// For more information on each option (and a full list of options) go to\n// https://next-auth.js.org/configuration/options\nconst authOptions = {\n    // https://next-auth.js.org/configuration/providers/oauth\n    providers: [\n        next_auth_providers_azure_ad__WEBPACK_IMPORTED_MODULE_1___default()({\n            clientId: process.env.AZURE_AD_CLIENT_ID,\n            clientSecret: process.env.AZURE_AD_CLIENT_SECRET,\n            tenantId: process.env.AZURE_AD_TENANT_ID\n        })\n    ],\n    secret: process.env.NEXTAUTH_SECRET,\n    debug: true\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_auth__WEBPACK_IMPORTED_MODULE_0___default()(authOptions));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFxRDtBQUNLO0FBRTFELHlFQUF5RTtBQUN6RSxpREFBaUQ7QUFDMUMsTUFBTUUsY0FBK0I7SUFDMUMseURBQXlEO0lBQ3pEQyxXQUFXO1FBQ1ZGLG1FQUFlQSxDQUFDO1lBQ1JHLFVBQVVDLFFBQVFDLEdBQUcsQ0FBQ0Msa0JBQWtCO1lBQ3hDQyxjQUFjSCxRQUFRQyxHQUFHLENBQUNHLHNCQUFzQjtZQUNoREMsVUFBVUwsUUFBUUMsR0FBRyxDQUFDSyxrQkFBa0I7UUFDMUM7S0FDTjtJQUNEQyxRQUFRUCxRQUFRQyxHQUFHLENBQUNPLGVBQWU7SUFDbkNDLE9BQU0sSUFBSTtBQUNaLEVBQUM7QUFFRCxpRUFBZWQsZ0RBQVFBLENBQUNFLFlBQVlBLEVBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9wYWdlcy9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdLnRzPzJlOGIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IE5leHRBdXRoLCB7IE5leHRBdXRoT3B0aW9ucyB9IGZyb20gXCJuZXh0LWF1dGhcIlxuaW1wb3J0IEF6dXJlQURQcm92aWRlciBmcm9tIFwibmV4dC1hdXRoL3Byb3ZpZGVycy9henVyZS1hZFwiXG5cbi8vIEZvciBtb3JlIGluZm9ybWF0aW9uIG9uIGVhY2ggb3B0aW9uIChhbmQgYSBmdWxsIGxpc3Qgb2Ygb3B0aW9ucykgZ28gdG9cbi8vIGh0dHBzOi8vbmV4dC1hdXRoLmpzLm9yZy9jb25maWd1cmF0aW9uL29wdGlvbnNcbmV4cG9ydCBjb25zdCBhdXRoT3B0aW9uczogTmV4dEF1dGhPcHRpb25zID0ge1xuICAvLyBodHRwczovL25leHQtYXV0aC5qcy5vcmcvY29uZmlndXJhdGlvbi9wcm92aWRlcnMvb2F1dGhcbiAgcHJvdmlkZXJzOiBbXG4gICBBenVyZUFEUHJvdmlkZXIoe1xuICAgICAgICAgICBjbGllbnRJZDogcHJvY2Vzcy5lbnYuQVpVUkVfQURfQ0xJRU5UX0lELFxuICAgICAgICAgICBjbGllbnRTZWNyZXQ6IHByb2Nlc3MuZW52LkFaVVJFX0FEX0NMSUVOVF9TRUNSRVQsXG4gICAgICAgICAgIHRlbmFudElkOiBwcm9jZXNzLmVudi5BWlVSRV9BRF9URU5BTlRfSUQsXG4gICAgICAgICB9KSxcbiAgXSxcbiAgc2VjcmV0OiBwcm9jZXNzLmVudi5ORVhUQVVUSF9TRUNSRVQgYXMgc3RyaW5nLFxuICBkZWJ1Zzp0cnVlLFxufVxuXG5leHBvcnQgZGVmYXVsdCBOZXh0QXV0aChhdXRoT3B0aW9ucylcbiJdLCJuYW1lcyI6WyJOZXh0QXV0aCIsIkF6dXJlQURQcm92aWRlciIsImF1dGhPcHRpb25zIiwicHJvdmlkZXJzIiwiY2xpZW50SWQiLCJwcm9jZXNzIiwiZW52IiwiQVpVUkVfQURfQ0xJRU5UX0lEIiwiY2xpZW50U2VjcmV0IiwiQVpVUkVfQURfQ0xJRU5UX1NFQ1JFVCIsInRlbmFudElkIiwiQVpVUkVfQURfVEVOQU5UX0lEIiwic2VjcmV0IiwiTkVYVEFVVEhfU0VDUkVUIiwiZGVidWciXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/auth/[...nextauth].ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/auth/[...nextauth].ts"));
module.exports = __webpack_exports__;

})();